/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI.Cliente.Selecionar;

import DAO.ClienteDAO;
import util.FXMLUtil;
import Verificacao.VerificarCliente;
import classes.Cliente;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Guillermo1
 */
public class FXMLClienteSelecionarController implements Initializable {

    @FXML
    private  TableView<Cliente> tabela;
    @FXML
    private  TableColumn<Cliente,Integer> tcId;
    @FXML
    private  TableColumn<Cliente, Long> tcCpf;
    @FXML
    private  TableColumn<Cliente, String> tcNome;
    @FXML
    private  TableColumn<Cliente, String> tcEmail;
    @FXML
    private  TableColumn<Cliente, Integer> tcCom;
    @FXML
    private  TableColumn<Cliente, Integer> tcMon;
    @FXML
    private TextField tfId;
    @FXML
    private AnchorPane anchorPane;
    private Stage stageAtual;
    private final ObservableList<Cliente> clientes = FXCollections.observableArrayList();
    private static Integer id;

    public void inicializarTabela() {
        tcId.setCellValueFactory(new PropertyValueFactory("id"));
        tcCpf.setCellValueFactory(new PropertyValueFactory("cpf"));
        tcNome.setCellValueFactory(new PropertyValueFactory("nome"));
        tcEmail.setCellValueFactory(new PropertyValueFactory("email"));
        tcMon.setCellValueFactory(new PropertyValueFactory("mon"));
        tcCom.setCellValueFactory(new PropertyValueFactory("com"));
    }

    @FXML
    public void colocarTudoTabela() throws SQLException {
        ResultSet res = ClienteDAO.selecionaTudo();
        while (res.next()) {
            clientes.add(new Cliente(res.getInt(1), res.getLong(2), res.getString(3), res.getString(4), res.getInt(5), res.getInt(6)));
        }
        tabela.setItems(clientes);
        //tabela.getColumns().addAll(tcId, tcCpf, tcNome, tcEmail, tcMon, tcCom);
    }

    @FXML
    public void colocarTudoTabela(ActionEvent event) throws SQLException {
        clientes.removeAll(clientes);
        ResultSet res = ClienteDAO.selecionaTudo();
        while (res.next()) {
            clientes.add(new Cliente(res.getInt(1), res.getLong(2), res.getString(3), res.getString(4), res.getInt(5), res.getInt(6)));
        }
        tabela.setItems(clientes);
        //tabela.getColumns().addAll(tcId, tcCpf, tcNome, tcEmail, tcMon, tcCom);
    }

    @FXML
    public void colocarMaisCompram(ActionEvent event) throws SQLException {
        clientes.removeAll(clientes);
        ResultSet res = ClienteDAO.selecionaMaisCompram();
        while (res.next()) {
            clientes.add(new Cliente(res.getInt(1), res.getLong(2), res.getString(3), res.getString(4), res.getInt(5), res.getInt(6)));
        }
        tabela.setItems(clientes);
       // tabela.getColumns().addAll(tcId, tcCpf, tcNome, tcEmail, tcMon, tcCom);
    }

    @FXML
    public void colocarMaisMonetizam(ActionEvent event) throws SQLException {
        clientes.removeAll(clientes);
        ResultSet res = ClienteDAO.selecionaMaisMonetiza();
        while (res.next()) {
            clientes.add(new Cliente(res.getInt(1), res.getLong(2), res.getString(3), res.getString(4), res.getInt(5), res.getInt(6)));
        }
        tabela.setItems(clientes);
        //tabela.getColumns().addAll(tcId, tcCpf, tcNome, tcEmail, tcMon, tcCom);
    }

    @FXML
    public void abrirAtualizarCliente(ActionEvent event) throws IOException {
        stageAtual = (Stage) anchorPane.getScene().getWindow();
        try { 
            if(tfId.getText().equals("")){
                    throw new Exception("Digite algum cliente!");
            }
            id = Integer.parseInt(tfId.getText());                   
            if (!VerificarCliente.clienteExiste(id)) {
                throw new Exception("Cliente não existe!");
            }
            tfId.setText("");
            FXMLUtil.abrirJanela("/GUI/Cliente/Atualizar/FXMLClienteAtualizar.fxml", "Atualizar Cliente", stageAtual, true);
        } catch (Exception ex) {
            //ex.printStackTrace();
            FXMLUtil.abrirErro(ex, stageAtual);
        }
    }

    @FXML
    public void abrirCadastrarCliente(ActionEvent event) throws IOException {
        stageAtual = (Stage) anchorPane.getScene().getWindow();
        FXMLUtil.abrirJanela("/GUI/Cliente/Cadastrar/FXMLClienteCadastrar.fxml", "Cadastrar Cliente", stageAtual, true);
    }

    @FXML
    public void deletar(ActionEvent event) throws SQLException, IOException {
        stageAtual = (Stage) anchorPane.getScene().getWindow();
        try {
            if (!VerificarCliente.clienteExiste(Integer.parseInt(tfId.getText()))) {
                throw new Exception("Cliente não existe!");
            }else if(tfId.getText().isEmpty()){
                throw new Exception("Digite algum cliente!");
            }
            ClienteDAO.deletar(Integer.parseInt(tfId.getText()));
            colocarTudoTabela();
        } catch (Exception ex) {
            FXMLUtil.abrirErro(ex, stageAtual);
        }
    }

    public static int getId() {
        return id;
    }

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        inicializarTabela();
        try {
            colocarTudoTabela();
        } catch (SQLException ex) {
            Logger.getLogger(FXMLClienteSelecionarController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
