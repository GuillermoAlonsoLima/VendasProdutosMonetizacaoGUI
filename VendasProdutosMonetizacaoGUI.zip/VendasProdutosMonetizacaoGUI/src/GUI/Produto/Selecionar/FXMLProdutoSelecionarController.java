/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI.Produto.Selecionar;

import DAO.ProdutoDAO;
import util.FXMLUtil;
import Verificacao.VerificarProduto;
import classes.Produto;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Guillermo1
 */
public class FXMLProdutoSelecionarController implements Initializable {
    @FXML private final TableView<Produto> tabela = new TableView<>();
    @FXML private final TableColumn<Produto,String> tcId = new TableColumn<>("ID");
    @FXML private final TableColumn<Produto,String> tcNome = new TableColumn<>("Nome");
    @FXML private final TableColumn<Produto,String> tcPreco = new TableColumn<>("Preço");
    @FXML private final TableColumn<Produto,String> tcVendas = new TableColumn<>("Vendas");
    @FXML private TextField tfId;
    @FXML private AnchorPane anchorPane;
    private Stage stageAtual;
    private final ObservableList<Produto> produtos = FXCollections.observableArrayList();
    private static int id;
    
    public void inicializarTabela(){
        tcId.setCellValueFactory(new PropertyValueFactory("id"));
        tcNome.setCellValueFactory(new PropertyValueFactory("nome"));
        tcPreco.setCellValueFactory(new PropertyValueFactory("preco"));
        tcVendas.setCellValueFactory(new PropertyValueFactory("vendas"));
    }
    
    @FXML public void colocarTudoTabela() throws SQLException{
        ResultSet res = ProdutoDAO.selecionaTudo();
        while(res.next()){
            produtos.add(new Produto(res.getInt(1),res.getString(2),res.getDouble(3),res.getInt(4)));
        }
        tabela.setItems(produtos);
        //tabela.getColumns().addAll(tcId,tcNome,tcPreco,tcVendas);
    }
    
    @FXML public void colocarTudoTabela(ActionEvent event) throws SQLException{
        produtos.removeAll(produtos);
        ResultSet res = ProdutoDAO.selecionaTudo();
        while(res.next()){
            produtos.add(new Produto(res.getInt(1),res.getString(2),res.getDouble(3),res.getInt(4)));        }
        tabela.setItems(produtos);
        //tabela.getColumns().addAll(tcId,tcNome,tcPreco,tcVendas);
    }
    
    @FXML public void colocarMaisVendidos(ActionEvent event) throws SQLException{
        produtos.removeAll(produtos);
        ResultSet res = ProdutoDAO.selecionarMaisVendidos();
        while(res.next()){
            produtos.add(new Produto(res.getInt(1),res.getString(2),res.getDouble(3),res.getInt(4)));
        }
        tabela.setItems(produtos);
        //tabela.getColumns().addAll(tcId,tcNome,tcPreco,tcVendas);
    }
        
    @FXML public void abrirAtualizarProduto(ActionEvent event) throws IOException{
        stageAtual = (Stage)anchorPane.getScene().getWindow();
        try{
            if(tfId.getText().equals("")){
                    throw new Exception("Digite algum cliente!");
            }
            id = Integer.parseInt(tfId.getText()); 
            if(!VerificarProduto.produtoExiste(Integer.parseInt(tfId.getText()))){
                throw new Exception("Produto não existe!");
            }
            tfId.setText("");
            FXMLUtil.abrirJanela("/GUI/Produto/Atualizar/FXMLProdutoAtualizar.fxml", "Atualizar Produto", stageAtual, true);
        }catch(Exception ex){
            FXMLUtil.abrirErro(ex, stageAtual);
        }
    }
    
    @FXML public void abrirCadastrarProduto(ActionEvent event) throws IOException{
            FXMLUtil.abrirJanela("/GUI/Produto/Cadastrar/FXMLProdutoCadastrar.fxml", "Cadastrar Produto", stageAtual, true);
     }
    
    @FXML public void deletar(ActionEvent event) throws SQLException, IOException{
        stageAtual = (Stage)anchorPane.getScene().getWindow();
        try{
            if(!VerificarProduto.produtoExiste(Integer.parseInt(tfId.getText()))){
                throw new Exception("Produto não existe!");
            }
            ProdutoDAO.deletar(Integer.parseInt(tfId.getText()));
            colocarTudoTabela();
        }catch(Exception ex){
            FXMLUtil.abrirErro(ex, stageAtual);
        }
    }
    
    public static int getId(){
        return id;
    }
    
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        inicializarTabela();
        try {
            colocarTudoTabela();
        } catch (SQLException ex) {
            Logger.getLogger(FXMLProdutoSelecionarController.class.getName()).log(Level.SEVERE, null, ex);
        }
    } 
    
}
