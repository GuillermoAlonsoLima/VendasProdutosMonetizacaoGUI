/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI.Conta.Atualizar;

import Conexao.Conexao;
import DAO.ClienteDAO;
import DAO.ContaDAO;
import GUI.Conta.Selecionar.FXMLContaSelecionarController;
import util.FXMLUtil;
import Verificacao.VerificarConta;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Guillermo1
 */
public class FXMLContaAtualizarController implements Initializable {
    @FXML private TextField tfUsuario;
    @FXML private PasswordField pfSenha;
    @FXML private TextField tfSaldo;
    @FXML private final ChoiceBox<Integer> cbCliente = new ChoiceBox<>();
    @FXML private AnchorPane anchorPane;
    private Stage stageAtual;
    private final ObservableList<Integer> clientes = FXCollections.observableArrayList();
    private int id;
    
    @FXML public void cadastrar(ActionEvent event) throws IOException{
        stageAtual = (Stage)anchorPane.getScene().getWindow();
        try{
            VerificarConta.verificarUsuario(tfUsuario.getText(),true);
            VerificarConta.verificarSenha(pfSenha.getText());
            ContaDAO.cadastrar(tfUsuario.getText(),pfSenha.getText(),Double.parseDouble(tfSaldo.getText()),cbCliente.getSelectionModel().getSelectedItem());
        }catch(Exception e){
            FXMLUtil.abrirErro(e, stageAtual);
        }
    }    
    
    public void inicializarValores() throws Exception{
        ResultSet res = Conexao.selecionar("SELECT * FROM CONTA WHERE ID = "+id+";");
        while(res.next()){
            tfUsuario.setText(res.getString(2));
            pfSenha.setText(res.getString(3));
            tfSaldo.setText(res.getString(4));
            preencherChoiceBox();
        }
    }
    
    public void preencherChoiceBox() throws Exception{
        ResultSet res = ClienteDAO.selecionaTudo();
        if(!res.isBeforeFirst())
            throw new Exception("Não há clientes cadastrados!");
        while(res.next()){
            clientes.add(res.getInt(1));
        }
        cbCliente.setItems(clientes);
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        id = FXMLContaSelecionarController.getId();
        try {
            inicializarValores();
        } catch (Exception ex) {
            Logger.getLogger(FXMLContaAtualizarController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    
    
}
