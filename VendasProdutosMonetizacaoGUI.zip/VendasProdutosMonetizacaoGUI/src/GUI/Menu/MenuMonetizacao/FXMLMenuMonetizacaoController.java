/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI.Menu.MenuMonetizacao;

import util.FXMLUtil;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Guillermo1
 */
public class FXMLMenuMonetizacaoController implements Initializable {
    @FXML private AnchorPane anchorPane;
    private Stage stageAtual;
    
    @FXML public void abrirCompra() throws IOException{
        FXMLUtil.abrirJanela("/GUI/Monetizacao/Comprar/FXMLComprar.fxml", "Comprar", stageAtual, true);
    }
    
    @FXML public void abrirDepositar() throws IOException{
        FXMLUtil.abrirJanela("/GUI/Monetizacao/Depositar/FXMLDepositar.fxml", "Depositar", stageAtual, true);
    }
    
    @FXML public void abrirRetirar() throws IOException{
        FXMLUtil.abrirJanela("/GUI/Monetizacao/Retirar/FXMLRetirar.fxml", "Retirar", stageAtual, true);
    }
    
    @FXML public void abrirTransferir() throws IOException{
        FXMLUtil.abrirJanela("/GUI/Monetizacao/Transferir/FXMLTransferir.fxml", "Transferir", stageAtual, true);
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
