/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI.Menu.MenuPrincipal;

import util.FXMLUtil;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Guillermo1
 */
public class FXMLMenuPrincipalController implements Initializable {
    @FXML private AnchorPane anchorPane;
    private Stage stageAtual;
    
    @FXML public void abrirCliente(ActionEvent event){
        try{
            stageAtual = (Stage)anchorPane.getScene().getWindow();
            FXMLUtil.abrirJanela("/GUI/Cliente/Selecionar/FXMLClienteSelecionar.fxml", "Cliente", stageAtual, true);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    @FXML public void abrirConta(ActionEvent event){
        try{
            stageAtual = (Stage)anchorPane.getScene().getWindow();
            FXMLUtil.abrirJanela("/GUI/Conta/Selecionar/FXMLContaSelecionar.fxml", "Conta", stageAtual, true);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    @FXML public void abrirProduto(ActionEvent event){
        try{
            stageAtual = (Stage)anchorPane.getScene().getWindow();
            FXMLUtil.abrirJanela("/GUI/Produto/Selecionar/FXMLProdutoSelecionar.fxml", "Produto", stageAtual, true);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    @FXML public void abrirVendas(ActionEvent event){
        try{
            stageAtual = (Stage)anchorPane.getScene().getWindow();
            FXMLUtil.abrirJanela("/GUI/Vendas/Selecionar/FXMLVendasSelecionar.fxml", "Vendas", stageAtual, true);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    @FXML public void abrirLogin(ActionEvent event){
        try{
            stageAtual = (Stage)anchorPane.getScene().getWindow();
            FXMLUtil.abrirJanela("/GUI/Login/FXMLLogin.fxml", "Vendas", stageAtual, true);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
