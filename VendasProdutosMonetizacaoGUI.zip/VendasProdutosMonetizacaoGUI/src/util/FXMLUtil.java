/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import GUI.Mensagem.FXMLMensagemController;
import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 *
 * @author Guillermo1
 */
public class FXMLUtil {
    public static void abrirJanela(String url,String titulo,Stage primaryStage,boolean travado) throws IOException{
        Parent root = FXMLLoader.load(FXMLUtil.class.getResource(url));//controller.getClass().getResource(url));        
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.setTitle(titulo);
        if(travado == true){
            stage.initModality(Modality.WINDOW_MODAL);
            stage.initOwner(primaryStage);
        }
        stage.show();
    }
    
    public static Object getController(String url){
        FXMLLoader loader = new FXMLLoader(FXMLUtil.class.getResource(url));
        return loader.getController();        
    }
    
    public static void abrirErro(Exception ex,Stage stageAtual) throws IOException{
        FXMLMensagemController.setMessage(ex.getMessage());
        FXMLUtil.abrirJanela("/GUI/Mensagem/FXMLMensagem.fxml", "Erro", stageAtual, true);
    }
}
