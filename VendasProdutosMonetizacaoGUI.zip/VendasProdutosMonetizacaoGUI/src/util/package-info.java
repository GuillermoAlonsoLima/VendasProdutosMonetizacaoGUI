/* Util
 * Possui classes auxiliares
 */
package util;
